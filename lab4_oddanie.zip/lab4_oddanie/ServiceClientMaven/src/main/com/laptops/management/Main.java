package com.laptops.management;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.jws.WebService;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.xml.rpc.ServiceException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@WebService(name="Implementation")
public class Main {
	public static JComboBox firstArea = null;
	public static JComboBox secondArea = null;

	public static JComboBox physicalCores = null;
	public static JComboBox touchscreen = null;
	public static JComboBox ram = null;
	public static JComboBox processor = null;
	public static JComboBox graphicCard = null;
	public static JTextArea responseArea = null;
	
	static JTable table = new JTable();
	
	public static void loadAllLaptops(Implementation service) throws RemoteException {
		fillHeaderTranslations();
		Laptop[] allLaptops = service.getAllLaptops();
		Integer i = 1;
		String responseAllLaptops = "All laptops were loaded so combo boxes are with actual data!\n\n";
		HashSet<String> manufacturers = new HashSet<String>();
		
		HashSet<String> screenSizes = new HashSet<String>();
		
		HashSet<String> allPhysicalCore = new HashSet<String>();
		HashSet<String> allTouchscreen = new HashSet<String>();
		HashSet<String> allRam = new HashSet<String>();
		HashSet<String> allProcessor = new HashSet<String>();
		HashSet<String> allGraphicCard = new HashSet<String>();
		


		for(Laptop laptop : allLaptops) {
			    String manufacturer = laptop.getManufacturer();
			    String screenSize = laptop.getScreenSize();
			    String physicalCore = String.valueOf(laptop.getProcessorPhysicalCores());
			    String touchScreen = String.valueOf(laptop.getScreenTouchscreen());
			    String ramValue = laptop.getRam();
			    String processorValue = laptop.getProcessorName();
			    String graphicCardValue = laptop.getGraphicCardName();
			    
			    if(manufacturer != "null" && manufacturer != null && manufacturer.length() > 0) {
			    	manufacturers.add(manufacturer);
			    }
			    if(screenSize != "null" && screenSize != null && screenSize.length() > 0) {
			    	screenSizes.add(screenSize);
			    }
			    
			    if(physicalCore != "null" && physicalCore != null && physicalCore.length() > 0) {
			    	allPhysicalCore.add(physicalCore);
			    }
			    if(touchScreen != "null" && touchScreen != null && touchScreen.length() > 0) {
			    	allTouchscreen.add(touchScreen);
			    }
			    if(ramValue != "null" && ramValue != null && ramValue.length() > 0) {
			    	allRam.add(ramValue);
			    }
			    if(processorValue != "null" && processorValue != null && processorValue.length() > 0) {
			    	allProcessor.add(processorValue);
			    }
			    if(graphicCardValue != "null" && graphicCardValue != null && graphicCardValue.length() > 0) {
			    	allGraphicCard.add(graphicCardValue);
			    }
			    
				//System.out.println(laptop);
				ObjectMapper mapper = new ObjectMapper();
//				try {
//					responseAllLaptops += "\n " + String.valueOf(i) + ". " + mapper.writeValueAsString(laptop);
//				} catch (JsonProcessingException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//				i++;
				

			

			responseArea = new JTextArea("response...");
			responseArea.setText(responseAllLaptops);
			
			firstArea = new JComboBox(manufacturers.toArray());
			firstArea.addItem("");
			secondArea = new JComboBox(screenSizes.toArray());
			secondArea.addItem("");

			physicalCores = new JComboBox(allPhysicalCore.toArray());
	    	touchscreen = new JComboBox(allTouchscreen.toArray());
	    	ram = new JComboBox(allRam.toArray());
	    	processor = new JComboBox(allProcessor.toArray());
	    	graphicCard = new JComboBox(allGraphicCard.toArray());
	    	
	    	physicalCores.addItem("");
	    	touchscreen.addItem("");
	    	ram.addItem("");
	    	processor.addItem("");
	    	graphicCard.addItem("");
		}
	}
	
	public static void setDefaultValue(JComboBox comboBox) {
		if(comboBox == null || comboBox.getItemCount() == 0) {
			
		}else {
			comboBox.setSelectedIndex(0);
		}
	}
	
	public static void main(String args[]) throws ServiceException, RemoteException {
		ImplementationServiceLocator locator = new ImplementationServiceLocator();
		Implementation service = locator.getImplementation();
		
		
		JFrame frame = new JFrame("Integracja systemów - Ryszard Rogalski");

        frame.setSize(1200, 700);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));

        JButton getNumberOfLaptopsFromManufacturer = new JButton("Callout");
        getNumberOfLaptopsFromManufacturer.setSize(100, 100);
        getNumberOfLaptopsFromManufacturer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	try {
					int result = service.getNumberOfLaptopsFromManufacturer(String.valueOf(firstArea.getSelectedItem()));
					System.out.println(result);
					responseArea.setText("Laptops from this manfucaturer : " + String.valueOf(result));
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
        });
        
        JButton getNumberOfLaptopsWithDesiredScreenRatio = new JButton("Callout");
        getNumberOfLaptopsWithDesiredScreenRatio.setSize(100, 100);
        getNumberOfLaptopsWithDesiredScreenRatio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	try {
					int result = service.getNumberOfLaptopsWithDesiredScreenSize(String.valueOf(secondArea.getSelectedItem()));
					System.out.println(result);
					responseArea.setText("Laptops with this screen size: " + String.valueOf(result));
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
        });
        
        JButton getLaptopsWithDesiredAttributes = new JButton("Callout");
        getLaptopsWithDesiredAttributes.setSize(100, 100);
        getLaptopsWithDesiredAttributes.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	try {
					Laptop[] result = service.getLaptopsWithDesiredAttributes(
							String.valueOf(physicalCores.getSelectedItem()),
							String.valueOf(touchscreen.getSelectedItem()),
							String.valueOf(ram.getSelectedItem()),
							String.valueOf(processor.getSelectedItem()),
							String.valueOf(graphicCard.getSelectedItem())
							);
					Integer i = 1;
					String response = "";
					
					DefaultTableModel model = new DefaultTableModel();
			    	for (String header: headers) {
		                model.addColumn(header);
		            }
			    	
			    	List<Vector<String>> rows = new ArrayList<Vector<String>>();
					if(result != null) {
						response = "Total laptops found: " + String.valueOf(result.length);
						for(Laptop laptop : result) {
						
							Vector<String> row = new Vector<String>();
							row.add(laptop.getManufacturer());
							row.add(laptop.getScreenSize());
	
							row.add(laptop.getScreenType());
	
							row.add(laptop.getScreenTouchscreen());
							row.add(laptop.getProcessorName());
	
							row.add(String.valueOf(laptop.getProcessorPhysicalCores()));
	
							row.add(laptop.getProcessorSpeed());
							row.add(laptop.getRam());
							row.add(laptop.getDiscStorage());
							row.add(laptop.getDiscType());
							row.add(laptop.getGraphicCardName());
							row.add(laptop.getGraphicCardMemory());
							row.add(laptop.getOs());
							row.add(laptop.getDiscReader());
	
							System.out.println(laptop);
							
					    	
	//						ObjectMapper mapper = new ObjectMapper();
	//						try {
	//							response += "\n " + String.valueOf(i) + ". " + mapper.writeValueAsString(laptop);
	//						} catch (JsonProcessingException e1) {
	//							// TODO Auto-generated catch block
	//							e1.printStackTrace();
	//						}
							i++;
							rows.add(row);
						}
						
					}
					
					if(result == null || result.length == 0) {
						response = "No results found...";
					}
					for(Vector<String> row : rows) {
						model.addRow(row);
					}
					table.setModel(model);

					responseArea.setText(response);
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
        });
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(1000, 300));
        buttonPanel.setMaximumSize(buttonPanel.getPreferredSize());
        buttonPanel.setMinimumSize(buttonPanel.getPreferredSize());

        buttonPanel.setLayout(new GridLayout(1,3));
        buttonPanel.setSize(1920, 150);
        buttonPanel.setBorder(BorderFactory.createTitledBorder("WebService callouts"));
        
        
        loadAllLaptops(service);

        
        setDefaultValue(firstArea);
        setDefaultValue(secondArea);
   
    	
    	
        setDefaultValue(physicalCores);
        setDefaultValue(touchscreen);
        setDefaultValue(ram);
        setDefaultValue(processor);
        setDefaultValue(graphicCard);

    	JPanel getNumberOfLaptopsFromManufacturerPanel = new JPanel();
    	getNumberOfLaptopsFromManufacturerPanel.setPreferredSize(new Dimension(1000, 300));
    	getNumberOfLaptopsFromManufacturerPanel.setMaximumSize(buttonPanel.getPreferredSize());
    	getNumberOfLaptopsFromManufacturerPanel.setMinimumSize(buttonPanel.getPreferredSize());

    	getNumberOfLaptopsFromManufacturerPanel.setLayout(new GridLayout(7,1));
    	getNumberOfLaptopsFromManufacturerPanel.setSize(500,300);
    	getNumberOfLaptopsFromManufacturerPanel.setBorder(BorderFactory.createTitledBorder("getNumberOfLaptopsFromManufacturer"));
    	
    	
    	JPanel getNumberOfLaptopsWithDesiredScreenRatioPanel = new JPanel();
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.setPreferredSize(new Dimension(1000, 300));
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.setMaximumSize(buttonPanel.getPreferredSize());
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.setMinimumSize(buttonPanel.getPreferredSize());

    	getNumberOfLaptopsWithDesiredScreenRatioPanel.setLayout(new GridLayout(7,1));
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.setSize(500,300);
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.setBorder(BorderFactory.createTitledBorder("getNumberOfLaptopsWithDesiredScreenRatio"));
    	
    	
    	
    	JPanel getLaptopsWithDesiredAttributesPanel = new JPanel();
    	getLaptopsWithDesiredAttributesPanel.setPreferredSize(new Dimension(1000, 300));
    	getLaptopsWithDesiredAttributesPanel.setMaximumSize(buttonPanel.getPreferredSize());
    	getLaptopsWithDesiredAttributesPanel.setMinimumSize(buttonPanel.getPreferredSize());

    	getLaptopsWithDesiredAttributesPanel.setLayout(new GridLayout(8,1));
    	getLaptopsWithDesiredAttributesPanel.setSize(500,300);
    	getLaptopsWithDesiredAttributesPanel.setBorder(BorderFactory.createTitledBorder("getLaptopsWithDesiredAttributes"));
        
    	getNumberOfLaptopsFromManufacturerPanel.add(getNumberOfLaptopsFromManufacturer);
    	getNumberOfLaptopsFromManufacturerPanel.add(new JLabel("Manufacturer:"));
    	getNumberOfLaptopsFromManufacturerPanel.add(firstArea);

    	getNumberOfLaptopsWithDesiredScreenRatioPanel.add(getNumberOfLaptopsWithDesiredScreenRatio);
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.add(new JLabel("Screen size:"));
    	getNumberOfLaptopsWithDesiredScreenRatioPanel.add(secondArea);
    	
    	getLaptopsWithDesiredAttributesPanel.add(getLaptopsWithDesiredAttributes);
    	getLaptopsWithDesiredAttributesPanel.add(new JLabel(""));
    	getLaptopsWithDesiredAttributesPanel.add(new JLabel("Physical Cores:"));
    	getLaptopsWithDesiredAttributesPanel.add(physicalCores);
    	getLaptopsWithDesiredAttributesPanel.add(new JLabel("Touchscreen:"));
    	getLaptopsWithDesiredAttributesPanel.add(touchscreen);
    	getLaptopsWithDesiredAttributesPanel.add(new JLabel("Ram:"));
    	getLaptopsWithDesiredAttributesPanel.add(ram);
    	getLaptopsWithDesiredAttributesPanel.add(new JLabel("Processor:"));
    	getLaptopsWithDesiredAttributesPanel.add(processor);
    	getLaptopsWithDesiredAttributesPanel.add(new JLabel("Graphic Card:"));
    	getLaptopsWithDesiredAttributesPanel.add(graphicCard);
    	
        buttonPanel.add(getNumberOfLaptopsFromManufacturerPanel);
        buttonPanel.add(getNumberOfLaptopsWithDesiredScreenRatioPanel);
        buttonPanel.add(getLaptopsWithDesiredAttributesPanel);

        
        
        JPanel response = new JPanel();
        response.setPreferredSize(new Dimension(1000, 90));
        response.setMaximumSize(buttonPanel.getPreferredSize());
        response.setMinimumSize(buttonPanel.getPreferredSize());

        response.setLayout(new GridLayout(1,1));
        response.setSize(1920, 150);
        response.setBorder(BorderFactory.createTitledBorder("Utilities"));
        
        JButton XMLExport = new JButton("Export (.xml)");
        XMLExport.setSize(100, 100);
        response.add(XMLExport);
        
        XMLExport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	try {
                    TableModel model = table.getModel();
                    File f = new File("savedDane.xml");
                    f.createNewFile();
                    System.out.println(f.getAbsolutePath());
                    
                    FileWriter xml = new FileWriter(f);
                    xml.write("<laptops>" + "\n");

                    HashMap<String, Integer> howManyChildren = new HashMap<String, Integer>();
                    howManyChildren.put("screen", 3);
                    howManyChildren.put("processor", 3);
                    howManyChildren.put("disc", 2);
                    howManyChildren.put("graphic_card", 2);
                    
                    HashMap<String, String> parentAfterMarkdown = new HashMap<String, String>();
                    parentAfterMarkdown.put("manufacturer", "screen");
                    parentAfterMarkdown.put("screen", "processor");
                    parentAfterMarkdown.put("ram", "disc");
                    parentAfterMarkdown.put("disc", "graphic_card");

                    for (int i = 0; i < model.getRowCount(); i++) {
                    	xml.write("\t<laptop>" + "\n");
                    	String previousColumnName = "";
                    	
                        HashMap<String, String> valueByKey = new HashMap<String, String>();
                        List<Integer> whichValuesToSkip = new ArrayList<Integer>();
                        
                        String previousColumn = "";
                        for (int j = 0; j < model.getColumnCount(); j++) {
                        	if(whichValuesToSkip.contains(j)) {
                        		continue;
                        	}
                        	
                        	String columnName = headerTranslations.get(model.getColumnName(j));
                        
							if(parentAfterMarkdown.get(previousColumn) != null) {
							    xml.write("\t\t<" + parentAfterMarkdown.get(previousColumn) + ">"); 
							    System.out.println("previousColumn = " + previousColumn);
							    System.out.println(howManyChildren);
							    Integer howManyChildrenForThisParent = howManyChildren.get(parentAfterMarkdown.get(previousColumn));
	                        	if(howManyChildrenForThisParent != null) {
	                        		for(int o = 0 ; o < howManyChildrenForThisParent; o++) {
	                        			System.out.println(j+o);
	                        			whichValuesToSkip.add(j+o);
	                        			String childrenColumnName = headerTranslations.get(model.getColumnName(j+o));
	                        			xml.write("\n\t\t\t<" + childrenColumnName + ">");
	                        			String childrenValue = (String) model.getValueAt(i, j+o);
	                        			if(childrenValue == null) {
	                        				childrenValue = "";
	                        			}
	                        			xml.write(childrenValue + "</" + childrenColumnName + ">");
	                        		}
	                        	}
	                        	xml.write("\n\t\t</" + parentAfterMarkdown.get(previousColumn) + ">\n");   
	                        	previousColumn = parentAfterMarkdown.get(previousColumn);
							}else {
								xml.write("\t\t<" + columnName + ">");
								String value = (String) model.getValueAt(i, j);
	                        	if(value == null) {
	                        		value = "";
	                        	}
	                            xml.write(value + "</" + columnName + ">" + "\n");
	                            previousColumn = columnName;
							}

                        	

                        }
                        xml.write("\t</laptop>\n");
                    }

                    xml.write("</laptops>");
                    xml.close();
                    
                   
                } catch (IOException ex) {
            		System.out.println("error");
                    System.out.println(ex.getMessage());
                }
            }
        });
        
        responseArea.setLineWrap(false);
        responseArea.setEditable(false);
       
        
        JScrollPane sp = new JScrollPane();
        sp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        sp.setViewportView(responseArea);
        
        response.add(sp);

        frame.add(buttonPanel);
        frame.add(response);

        

        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new GridLayout(0, 1));

        tablePanel.setBorder(BorderFactory.createTitledBorder("Data"));

        JScrollPane tabelPanelSP = new JScrollPane(table);

        tablePanel.add(tabelPanelSP);
        frame.add(tablePanel);

        DefaultTableModel initModel = new DefaultTableModel();

        for (String header: headers) {
            initModel.addColumn(header);
        }
        table.setModel(initModel);


        tablePanel.add(table.getTableHeader(), BorderLayout.CENTER);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
	}
	
    static HashMap <String, String> headerTranslations = new HashMap<String,String>();
    static List < String > headers = Arrays.asList(
            "Producent",
            "wielkość matrycy",
            "typ matrycy",
            "czy dotykowy ekran",
            "procesor",
            "liczba rdzeni fizyczynch",
            "taktowanie",
            "RAM",
            "pojemność dysku",
            "typ dysku",
            "karta graficzna",
            "pamięć karty graficznej",
            "system operacyjny",
            "Napęd optyczny");
	private static void fillHeaderTranslations() {
		headerTranslations.put("Producent", "manufacturer");
		headerTranslations.put("wielkość matrycy", "size");
		headerTranslations.put("typ matrycy", "type");
		headerTranslations.put("czy dotykowy ekran", "touchscreen");
		headerTranslations.put("procesor", "name");
		headerTranslations.put("liczba rdzeni fizyczynch", "physical_cores");
		headerTranslations.put("taktowanie", "clock_speed");
		headerTranslations.put("RAM", "ram");
		headerTranslations.put("pojemność dysku", "storage");
		headerTranslations.put("typ dysku", "type");
		headerTranslations.put("karta graficzna", "name");
		headerTranslations.put("pamięć karty graficznej", "memory");
		headerTranslations.put("system operacyjny", "os");
		headerTranslations.put("Napęd optyczny", "disc_reader");
	}
}
