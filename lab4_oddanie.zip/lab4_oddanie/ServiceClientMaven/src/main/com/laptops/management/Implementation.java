/**
 * Implementation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.laptops.management;

public interface Implementation extends java.rmi.Remote {
    public com.laptops.management.Laptop[] getLaptopsWithDesiredAttributes(java.lang.String a, java.lang.String b, java.lang.String c, java.lang.String d, java.lang.String e) throws java.rmi.RemoteException;
    public int getNumberOfLaptopsFromManufacturer(java.lang.String manufacturer) throws java.rmi.RemoteException;
    public int getNumberOfLaptopsWithDesiredScreenSize(java.lang.String screenSize) throws java.rmi.RemoteException;
    public com.laptops.management.Laptop[] getAllLaptops() throws java.rmi.RemoteException;
    public boolean checkIfEmpty(java.lang.String x) throws java.rmi.RemoteException;
}
