/**
 * Laptop.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.laptops.management;

public class Laptop  implements java.io.Serializable {
    private java.lang.String discReader;

    private java.lang.String discStorage;

    private java.lang.String discType;

    private java.lang.String graphicCardMemory;

    private java.lang.String graphicCardName;

    private java.lang.String manufacturer;

    private java.lang.String os;

    private java.lang.String processorName;

    private java.lang.Integer processorPhysicalCores;

    private java.lang.String processorSpeed;

    private java.lang.String ram;

    private java.lang.String screenSize;

    private java.lang.String screenTouchscreen;

    private java.lang.String screenType;

    public Laptop() {
    }

    public Laptop(
           java.lang.String discReader,
           java.lang.String discStorage,
           java.lang.String discType,
           java.lang.String graphicCardMemory,
           java.lang.String graphicCardName,
           java.lang.String manufacturer,
           java.lang.String os,
           java.lang.String processorName,
           java.lang.Integer processorPhysicalCores,
           java.lang.String processorSpeed,
           java.lang.String ram,
           java.lang.String screenSize,
           java.lang.String screenTouchscreen,
           java.lang.String screenType) {
           this.discReader = discReader;
           this.discStorage = discStorage;
           this.discType = discType;
           this.graphicCardMemory = graphicCardMemory;
           this.graphicCardName = graphicCardName;
           this.manufacturer = manufacturer;
           this.os = os;
           this.processorName = processorName;
           this.processorPhysicalCores = processorPhysicalCores;
           this.processorSpeed = processorSpeed;
           this.ram = ram;
           this.screenSize = screenSize;
           this.screenTouchscreen = screenTouchscreen;
           this.screenType = screenType;
    }


    /**
     * Gets the discReader value for this Laptop.
     * 
     * @return discReader
     */
    public java.lang.String getDiscReader() {
        return discReader;
    }


    /**
     * Sets the discReader value for this Laptop.
     * 
     * @param discReader
     */
    public void setDiscReader(java.lang.String discReader) {
        this.discReader = discReader;
    }


    /**
     * Gets the discStorage value for this Laptop.
     * 
     * @return discStorage
     */
    public java.lang.String getDiscStorage() {
        return discStorage;
    }


    /**
     * Sets the discStorage value for this Laptop.
     * 
     * @param discStorage
     */
    public void setDiscStorage(java.lang.String discStorage) {
        this.discStorage = discStorage;
    }


    /**
     * Gets the discType value for this Laptop.
     * 
     * @return discType
     */
    public java.lang.String getDiscType() {
        return discType;
    }


    /**
     * Sets the discType value for this Laptop.
     * 
     * @param discType
     */
    public void setDiscType(java.lang.String discType) {
        this.discType = discType;
    }


    /**
     * Gets the graphicCardMemory value for this Laptop.
     * 
     * @return graphicCardMemory
     */
    public java.lang.String getGraphicCardMemory() {
        return graphicCardMemory;
    }


    /**
     * Sets the graphicCardMemory value for this Laptop.
     * 
     * @param graphicCardMemory
     */
    public void setGraphicCardMemory(java.lang.String graphicCardMemory) {
        this.graphicCardMemory = graphicCardMemory;
    }


    /**
     * Gets the graphicCardName value for this Laptop.
     * 
     * @return graphicCardName
     */
    public java.lang.String getGraphicCardName() {
        return graphicCardName;
    }


    /**
     * Sets the graphicCardName value for this Laptop.
     * 
     * @param graphicCardName
     */
    public void setGraphicCardName(java.lang.String graphicCardName) {
        this.graphicCardName = graphicCardName;
    }


    /**
     * Gets the manufacturer value for this Laptop.
     * 
     * @return manufacturer
     */
    public java.lang.String getManufacturer() {
        return manufacturer;
    }


    /**
     * Sets the manufacturer value for this Laptop.
     * 
     * @param manufacturer
     */
    public void setManufacturer(java.lang.String manufacturer) {
        this.manufacturer = manufacturer;
    }


    /**
     * Gets the os value for this Laptop.
     * 
     * @return os
     */
    public java.lang.String getOs() {
        return os;
    }


    /**
     * Sets the os value for this Laptop.
     * 
     * @param os
     */
    public void setOs(java.lang.String os) {
        this.os = os;
    }


    /**
     * Gets the processorName value for this Laptop.
     * 
     * @return processorName
     */
    public java.lang.String getProcessorName() {
        return processorName;
    }


    /**
     * Sets the processorName value for this Laptop.
     * 
     * @param processorName
     */
    public void setProcessorName(java.lang.String processorName) {
        this.processorName = processorName;
    }


    /**
     * Gets the processorPhysicalCores value for this Laptop.
     * 
     * @return processorPhysicalCores
     */
    public java.lang.Integer getProcessorPhysicalCores() {
        return processorPhysicalCores;
    }


    /**
     * Sets the processorPhysicalCores value for this Laptop.
     * 
     * @param processorPhysicalCores
     */
    public void setProcessorPhysicalCores(java.lang.Integer processorPhysicalCores) {
        this.processorPhysicalCores = processorPhysicalCores;
    }


    /**
     * Gets the processorSpeed value for this Laptop.
     * 
     * @return processorSpeed
     */
    public java.lang.String getProcessorSpeed() {
        return processorSpeed;
    }


    /**
     * Sets the processorSpeed value for this Laptop.
     * 
     * @param processorSpeed
     */
    public void setProcessorSpeed(java.lang.String processorSpeed) {
        this.processorSpeed = processorSpeed;
    }


    /**
     * Gets the ram value for this Laptop.
     * 
     * @return ram
     */
    public java.lang.String getRam() {
        return ram;
    }


    /**
     * Sets the ram value for this Laptop.
     * 
     * @param ram
     */
    public void setRam(java.lang.String ram) {
        this.ram = ram;
    }


    /**
     * Gets the screenSize value for this Laptop.
     * 
     * @return screenSize
     */
    public java.lang.String getScreenSize() {
        return screenSize;
    }


    /**
     * Sets the screenSize value for this Laptop.
     * 
     * @param screenSize
     */
    public void setScreenSize(java.lang.String screenSize) {
        this.screenSize = screenSize;
    }


    /**
     * Gets the screenTouchscreen value for this Laptop.
     * 
     * @return screenTouchscreen
     */
    public java.lang.String getScreenTouchscreen() {
        return screenTouchscreen;
    }


    /**
     * Sets the screenTouchscreen value for this Laptop.
     * 
     * @param screenTouchscreen
     */
    public void setScreenTouchscreen(java.lang.String screenTouchscreen) {
        this.screenTouchscreen = screenTouchscreen;
    }


    /**
     * Gets the screenType value for this Laptop.
     * 
     * @return screenType
     */
    public java.lang.String getScreenType() {
        return screenType;
    }


    /**
     * Sets the screenType value for this Laptop.
     * 
     * @param screenType
     */
    public void setScreenType(java.lang.String screenType) {
        this.screenType = screenType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Laptop)) return false;
        Laptop other = (Laptop) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.discReader==null && other.getDiscReader()==null) || 
             (this.discReader!=null &&
              this.discReader.equals(other.getDiscReader()))) &&
            ((this.discStorage==null && other.getDiscStorage()==null) || 
             (this.discStorage!=null &&
              this.discStorage.equals(other.getDiscStorage()))) &&
            ((this.discType==null && other.getDiscType()==null) || 
             (this.discType!=null &&
              this.discType.equals(other.getDiscType()))) &&
            ((this.graphicCardMemory==null && other.getGraphicCardMemory()==null) || 
             (this.graphicCardMemory!=null &&
              this.graphicCardMemory.equals(other.getGraphicCardMemory()))) &&
            ((this.graphicCardName==null && other.getGraphicCardName()==null) || 
             (this.graphicCardName!=null &&
              this.graphicCardName.equals(other.getGraphicCardName()))) &&
            ((this.manufacturer==null && other.getManufacturer()==null) || 
             (this.manufacturer!=null &&
              this.manufacturer.equals(other.getManufacturer()))) &&
            ((this.os==null && other.getOs()==null) || 
             (this.os!=null &&
              this.os.equals(other.getOs()))) &&
            ((this.processorName==null && other.getProcessorName()==null) || 
             (this.processorName!=null &&
              this.processorName.equals(other.getProcessorName()))) &&
            ((this.processorPhysicalCores==null && other.getProcessorPhysicalCores()==null) || 
             (this.processorPhysicalCores!=null &&
              this.processorPhysicalCores.equals(other.getProcessorPhysicalCores()))) &&
            ((this.processorSpeed==null && other.getProcessorSpeed()==null) || 
             (this.processorSpeed!=null &&
              this.processorSpeed.equals(other.getProcessorSpeed()))) &&
            ((this.ram==null && other.getRam()==null) || 
             (this.ram!=null &&
              this.ram.equals(other.getRam()))) &&
            ((this.screenSize==null && other.getScreenSize()==null) || 
             (this.screenSize!=null &&
              this.screenSize.equals(other.getScreenSize()))) &&
            ((this.screenTouchscreen==null && other.getScreenTouchscreen()==null) || 
             (this.screenTouchscreen!=null &&
              this.screenTouchscreen.equals(other.getScreenTouchscreen()))) &&
            ((this.screenType==null && other.getScreenType()==null) || 
             (this.screenType!=null &&
              this.screenType.equals(other.getScreenType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDiscReader() != null) {
            _hashCode += getDiscReader().hashCode();
        }
        if (getDiscStorage() != null) {
            _hashCode += getDiscStorage().hashCode();
        }
        if (getDiscType() != null) {
            _hashCode += getDiscType().hashCode();
        }
        if (getGraphicCardMemory() != null) {
            _hashCode += getGraphicCardMemory().hashCode();
        }
        if (getGraphicCardName() != null) {
            _hashCode += getGraphicCardName().hashCode();
        }
        if (getManufacturer() != null) {
            _hashCode += getManufacturer().hashCode();
        }
        if (getOs() != null) {
            _hashCode += getOs().hashCode();
        }
        if (getProcessorName() != null) {
            _hashCode += getProcessorName().hashCode();
        }
        if (getProcessorPhysicalCores() != null) {
            _hashCode += getProcessorPhysicalCores().hashCode();
        }
        if (getProcessorSpeed() != null) {
            _hashCode += getProcessorSpeed().hashCode();
        }
        if (getRam() != null) {
            _hashCode += getRam().hashCode();
        }
        if (getScreenSize() != null) {
            _hashCode += getScreenSize().hashCode();
        }
        if (getScreenTouchscreen() != null) {
            _hashCode += getScreenTouchscreen().hashCode();
        }
        if (getScreenType() != null) {
            _hashCode += getScreenType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Laptop.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://management.laptops.com", "Laptop"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discReader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "discReader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discStorage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "discStorage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "discType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("graphicCardMemory");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "graphicCardMemory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("graphicCardName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "graphicCardName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "manufacturer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("os");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "os"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processorName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "processorName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processorPhysicalCores");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "processorPhysicalCores"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processorSpeed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "processorSpeed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ram");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "ram"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("screenSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "screenSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("screenTouchscreen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "screenTouchscreen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("screenType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://management.laptops.com", "screenType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
