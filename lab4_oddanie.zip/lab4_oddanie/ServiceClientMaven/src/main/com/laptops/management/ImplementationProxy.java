package com.laptops.management;

public class ImplementationProxy implements com.laptops.management.Implementation {
  private String _endpoint = null;
  private com.laptops.management.Implementation implementation = null;
  
  public ImplementationProxy() {
    _initImplementationProxy();
  }
  
  public ImplementationProxy(String endpoint) {
    _endpoint = endpoint;
    _initImplementationProxy();
  }
  
  private void _initImplementationProxy() {
    try {
      implementation = (new com.laptops.management.ImplementationServiceLocator()).getImplementation();
      if (implementation != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)implementation)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)implementation)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (implementation != null)
      ((javax.xml.rpc.Stub)implementation)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.laptops.management.Implementation getImplementation() {
    if (implementation == null)
      _initImplementationProxy();
    return implementation;
  }
  
  public int getNumberOfLaptopsFromManufacturer(java.lang.String manufacturer) throws java.rmi.RemoteException{
    if (implementation == null)
      _initImplementationProxy();
    return implementation.getNumberOfLaptopsFromManufacturer(manufacturer);
  }
  
  public com.laptops.management.Laptop[] getLaptopsWithDesiredAttributes(java.lang.String a, java.lang.String b, java.lang.String c, java.lang.String d, java.lang.String e) throws java.rmi.RemoteException{
    if (implementation == null)
      _initImplementationProxy();
    return implementation.getLaptopsWithDesiredAttributes(a, b, c, d, e);
  }
  
  public com.laptops.management.Laptop[] getAllLaptops() throws java.rmi.RemoteException{
    if (implementation == null)
      _initImplementationProxy();
    return implementation.getAllLaptops();
  }
  
  public int getNumberOfLaptopsWithDesiredScreenSize(java.lang.String screenSize) throws java.rmi.RemoteException{
    if (implementation == null)
      _initImplementationProxy();
    return implementation.getNumberOfLaptopsWithDesiredScreenSize(screenSize);
  }
  
  public boolean checkIfEmpty(java.lang.String x) throws java.rmi.RemoteException{
    if (implementation == null)
      _initImplementationProxy();
    return implementation.checkIfEmpty(x);
  }
  
  
}