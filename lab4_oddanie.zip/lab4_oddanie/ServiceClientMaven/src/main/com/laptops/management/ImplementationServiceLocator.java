/**
 * ImplementationServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.laptops.management;

public class ImplementationServiceLocator extends org.apache.axis.client.Service implements com.laptops.management.ImplementationService {

    public ImplementationServiceLocator() {
    }


    public ImplementationServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ImplementationServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for Implementation
    private java.lang.String Implementation_address = "http://localhost:8080/LaptopService/services/Implementation";

    public java.lang.String getImplementationAddress() {
        return Implementation_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ImplementationWSDDServiceName = "Implementation";

    public java.lang.String getImplementationWSDDServiceName() {
        return ImplementationWSDDServiceName;
    }

    public void setImplementationWSDDServiceName(java.lang.String name) {
        ImplementationWSDDServiceName = name;
    }

    public com.laptops.management.Implementation getImplementation() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(Implementation_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getImplementation(endpoint);
    }

    public com.laptops.management.Implementation getImplementation(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.laptops.management.ImplementationSoapBindingStub _stub = new com.laptops.management.ImplementationSoapBindingStub(portAddress, this);
            _stub.setPortName(getImplementationWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setImplementationEndpointAddress(java.lang.String address) {
        Implementation_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.laptops.management.Implementation.class.isAssignableFrom(serviceEndpointInterface)) {
                com.laptops.management.ImplementationSoapBindingStub _stub = new com.laptops.management.ImplementationSoapBindingStub(new java.net.URL(Implementation_address), this);
                _stub.setPortName(getImplementationWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("Implementation".equals(inputPortName)) {
            return getImplementation();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://management.laptops.com", "ImplementationService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://management.laptops.com", "Implementation"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("Implementation".equals(portName)) {
            setImplementationEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
