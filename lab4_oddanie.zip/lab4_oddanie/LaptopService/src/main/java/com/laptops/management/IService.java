package com.laptops.management;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import javax.jws.WebMethod;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.RPC)
public interface IService {
	@WebMethod public Integer getNumberOfLaptopsFromManufacturer(String manufacturer);
	@WebMethod public Integer getNumberOfLaptopsWithDesiredScreenSize(String screenSize);
	@WebMethod public Laptop[] getLaptopsWithDesiredAttributes(String a, String b, String c, String d, String e);
	@WebMethod public Laptop[] getAllLaptops();
}
