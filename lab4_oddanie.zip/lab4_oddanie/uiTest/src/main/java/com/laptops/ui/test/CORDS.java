package com.laptops.ui.test;

public class CORDS {
	public static Integer HIDE_ECLIPSE_X = 30;
	public static Integer HIDE_ECLIPSE_Y = 40;
	
	public static Integer SERVER_ICON_X = 1193;
	public static Integer SERVER_ICON_Y = 870;
	
	public static Integer CLIENT_ICON_X = 1290;
	public static Integer CLIENT_ICON_Y = 870;
	
	public static Integer SHOW_ECLIPSE_X = 1222;
	public static Integer SHOW_ECLIPSE_Y = 870;
}
