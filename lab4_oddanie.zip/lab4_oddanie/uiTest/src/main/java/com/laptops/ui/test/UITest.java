package com.laptops.ui.test;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.KeyStroke;


public class UITest {
	public static Timer timer;
	public static Integer i = 3;
	public static Integer timerDelay = 100;
	
	public void execute(Object reference) {
		JButton button = (JButton) reference;
		button.setText("Test starting in " + String.valueOf(i) + "...");
		
		if(timer == null) {
			timer = new Timer();
			timer.scheduleAtFixedRate(new TimerTask() {
				  @Override
				  public void run() {
					  	//System.out.println("Timer execution");
					    i -= 1;
						button.setText("Test starting in " + String.valueOf(i) + "...");
						if(i == 0) {
							button.setText("Test started!");
							timer.cancel();
							timer.purge();
							i = 3;
							timer = null;
							try {
								executeTest();
							} catch (AWTException | InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
				  }
				}, timerDelay, timerDelay);	
		}
	}
	
	
	protected void executeTest() throws AWTException, InterruptedException {
		intializeKeyStrokesHashMap();
		try{
			robot = new Robot();
			hideEclipse();
			openAppAndLoadDataFromTxt();
			modifyFirstRecord();
			writeWholeString("Apple");
			saveDataToDatabase();
			takeScreenshot("first");
			openClientApp();
			
			chooseAttributes();
			takeScreenshot("second");
			showEclipse();
			openXMLFile();
			takeScreenshot("third");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			showEclipse();
			System.exit(0);
		}
	}

	private void openXMLFile() throws InterruptedException {
		robot.mouseMove(184, 526);
		clickMouse();
		robot.delay(1000);
		robot.mouseMove(1368, 118);
		clickMouse();
	}


	private void chooseAttributes() throws InterruptedException {
		robot.mouseMove(997, 136);
		clickMouseSingle();
		
		
		robot.mouseMove(1008, 155);
		clickMouseSingle();
		
		robot.mouseMove(917, 108);
		clickMouseSingle();
		robot.delay(300);
		
		
		robot.mouseMove(1020, 198);
		clickMouseSingle();
		
		robot.mouseMove(1028, 201);
		clickMouseSingle();
		robot.delay(300);
		
		
		robot.mouseMove(1033, 232);
		clickMouseSingle();
		
		robot.mouseMove(1000, 265);
		clickMouseSingle();
		robot.delay(300);
		
		
		
		robot.mouseMove(923, 108);
		clickMouseSingle();
		robot.delay(300);
		
		
		
		robot.mouseMove(549, 420);
		clickMouseSingle();
		robot.delay(1000);

	}


	private void openClientApp() throws InterruptedException {
		robot.mouseMove(CORDS.CLIENT_ICON_X, CORDS.CLIENT_ICON_Y);
		clickMouse();
		robot.mouseMove(189, 177);
		clickMouseSingle();
		robot.delay(200);
		robot.mouseMove(200, 234);
		clickMouse();
		
		robot.delay(200);
		robot.mouseMove(368, 101);
		clickMouseSingle();
	}


	private void saveDataToDatabase() throws InterruptedException {
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.mouseMove(842, 96);
		clickMouse();
	}


	private void takeScreenshot(String string) throws IOException {
		File f= new File(string + ".png");
		f.delete();
		
		BufferedImage image = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
		ImageIO.write(image, "png", new File(string + ".png"));
	}


	private void modifyFirstRecord() throws InterruptedException {
		robot.mouseMove(91, 423);
		clickMouse();
		clickMouse();
	}


	private void intializeKeyStrokesHashMap() {
		for(Integer i = 0 ; i < 500 ; i ++) {
			String output = KeyEvent.getKeyText(i);
			keyStrokesMap.put(output, i);
			System.out.println(output);
			System.out.println(i);
		}
//		char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
//		for(char letter : alphabet) {
//			keyStrokesMap.put(String.valueOf(letter), KeyEvent.get);
//		}
	}


	private void showEclipse() throws InterruptedException {
		robot.mouseMove(CORDS.SHOW_ECLIPSE_X, CORDS.SHOW_ECLIPSE_Y);
		clickMouse();
		robot.delay(1000);
	}


	protected void clickMouse() throws InterruptedException {
		TimeUnit.SECONDS.sleep((long) 0.8);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
	    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
	    robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
	    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
	}
	
	protected void clickMouseSingle() throws InterruptedException {
		TimeUnit.SECONDS.sleep((long) 0.8);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
	    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
	}
	
	private static Robot robot = null;
	protected void openAppAndLoadDataFromTxt() throws InterruptedException {
		int xCoord = CORDS.SERVER_ICON_X;
		int yCoord = CORDS.SERVER_ICON_Y;

		robot.mouseMove(xCoord, yCoord);
		clickMouse();

		robot.mouseMove(297, 96);
		clickMouse();
		
		robot.mouseMove(515, 506);
		clickMouse();
		
		robot.mouseMove(986, 627);
		clickMouse();
	}
	
	private void writeText(String value, Boolean withShift) {
		if(withShift) {
			robot.keyPress(KeyEvent.VK_SHIFT);
		}
		robot.keyPress(keyStrokesMap.get(value));
		robot.keyRelease(keyStrokesMap.get(value));
		if(withShift) {
			robot.keyRelease(KeyEvent.VK_SHIFT);
		}
	};
	
	private static HashMap<String, Integer> keyStrokesMap = new HashMap<String, Integer>();
	private void writeWholeString(String string) {
		char[] value = string.toCharArray();
		
		for(char character : value) {
			System.out.println(character);
			System.out.println(keyStrokesMap.get(character));
			robot.delay(100);
			Boolean withShift = true;
			String letter = String.valueOf(character);
			if(letter.toLowerCase().equals(letter)) {
				withShift = false;
			}
			writeText(String.valueOf(character).toUpperCase(), withShift);
		}
	}

	private void hideEclipse() throws InterruptedException {
		robot.mouseMove(CORDS.HIDE_ECLIPSE_X, CORDS.HIDE_ECLIPSE_Y);
		clickMouse();
	}

	
	
}
