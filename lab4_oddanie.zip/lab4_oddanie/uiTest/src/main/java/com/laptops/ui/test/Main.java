package com.laptops.ui.test;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {
	public static void main(String args[]) {
		JFrame frame = new JFrame("Integracja systemów - Ryszard Rogalski");

        frame.setSize(450, 125);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.setLayout(new GridLayout(1, 4));
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(300, 300));
        buttonPanel.setMaximumSize(buttonPanel.getPreferredSize());
        buttonPanel.setMinimumSize(buttonPanel.getPreferredSize());

        buttonPanel.setLayout(new GridLayout(1,1));
        buttonPanel.setSize(500, 150);
        buttonPanel.setBorder(BorderFactory.createTitledBorder("UI Test"));
        
        JButton jbutton = new JButton("Start");
        jbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	new UITest().execute(e.getSource());
            }
        });
        
        jbutton.setPreferredSize(new Dimension(100, 25));
        buttonPanel.add(jbutton);
        
        frame.add(buttonPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setVisible(true);
	}
}
